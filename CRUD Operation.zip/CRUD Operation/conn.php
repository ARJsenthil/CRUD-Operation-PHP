<?php 
$serverName = "localhost";
$userName = "phpmyadmin";
$password = "777";
$dbName = "phpmyadmin";

$conn = new mysqli($serverName, $userName, $password, $dbName);
if($conn->connect_error) {
    die("Connection Failed : ". $conn->connect_error);
}
?>