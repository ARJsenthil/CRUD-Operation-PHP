<?php session_start();?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>List Users</title>
    <link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/datatables/datatables.min.css" rel="stylesheet">
    <link href="assets/css/master.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        #btn-close-form {
            padding: calc(var(--bs-modal-header-padding-y) * .5) calc(var(--bs-modal-header-padding-x) * .5);
            margin: calc(-.5 * var(--bs-modal-header-padding-y)) calc(-.5 * var(--bs-modal-header-padding-x)) calc(-.5 * var(--bs-modal-header-padding-y)) auto;
        }
    </style>
</head>
<body>
<?php
    include_once "conn.php"; // Database Connection

    if(isset($_SESSION['Alert'])) {
        if($_SESSION['Alert'] == true) {
            echo $_SESSION['Alert'];            //Activating Alert Box (eg : User Added, Edited, Deleted)
        }
        else if($_SESSION['Alert'] == false) {
            echo alertBox("Invalid", "Invalid URL", "warning");       //Activating Failed Alert Message Box
        }
        unset($_SESSION['Alert']);                  //Destring Alert Session
    }
    // User Details Array
    $userData = array( 
        "firstName" => "",
        "lastName" => "",
        "dob" => "",
        "email" => "",
        "password" => "",
        "status" => "",
        "profile" => "",
    );

    //Reset User Details
    function resetUserData($userData) {
        foreach($userData as $key => $value) {
            $userData[$key] = "";
        }
    }

    //Common Alert Box Function
    function alertBox($tittle, $text, $icon) {
        if($tittle) {
            return '<script>
            Swal.fire({
                title: "'.$tittle.'",
                text: "'.$text.'",
            icon: "'.$icon.'"
        })
        </script>';
        }
        else {
            return '<script> Swal.fire({
                position: "top-end",
                icon: "'.$icon.'",
                title: "'.$text.'",
                showConfirmButton: false,
                timer: 2500
            }); </script>';
        }
    }

    // For Add And Edit User
    if($_SERVER['REQUEST_METHOD'] == 'POST' && count($_POST) > 0) {
        $userData["firstName"] = $_POST["firstName"]; 
        $userData["lastName"] = $_POST["lastName"]; 
        $userData["email"] = $_POST["email"]; 
        $userData["dob"] = $_POST["dob"]; 
        $userData["password"] = $_POST["password"];
        $userData["status"] = $_POST["status"];

        //Checking Image Data is Comming or not 
        if(count($_FILES['profile']) > 0) {
            $imgDir = 'IMG-'.rand(9999, 100000).'.'.end(explode(".", $_FILES['profile']['name']));
            $userData["profile"] = $imgDir;
        }
        else {
            $userData["profile"] = "";
        }
        if(move_uploaded_file($_FILES['profile']['tmp_name'], 'uploads/'.$imgDir)) {
            if($_SESSION['actionType'] == "ADD") {
                $sql1 = "INSERT INTO `users_table`(`firstname`, `lastname`, `dob`, `email`, `password`, `status`, `profile`) VALUES ('$userData[firstName]','$userData[lastName]','$userData[dob]','$userData[email]','$userData[password]','$userData[status]','$userData[profile]')";
                if($conn->query($sql1)) {
                    $tittle = 'Added';
                    $text = 'User '.$userData["firstName"].' '.$userData["lastName"].' Added Successfully';
                    $_SESSION['Alert'] = alertBox('', $text, 'success');
                }
                else {
                    $_SESSION['Alert'] = false;
                }
            }
        }
        if( explode("-", $_SESSION['actionType'])[0] == "EDIT") {
                $id = explode("-", $_SESSION['actionType'])[1];
                echo $userData['dob'];
                if(move_uploaded_file($_FILES['profile']['tmp_name'], 'uploads/'.$imgDir)) {
                    $sql = "UPDATE `users_table` SET `firstname`='$userData[firstName]',`lastname`='$userData[lastName]',`dob`='$userData[dob]',`email`='$userData[email]',`password`='$userData[password]',`status`='$userData[status]',`profile`='$userData[profile]' WHERE  _id = $id";
                }
                else {
                    $sql = "UPDATE `users_table` SET `firstname`='$userData[firstName]',`lastname`='$userData[lastName]',`dob`='$userData[dob]',`email`='$userData[email]',`password`='$userData[password]',`status`='$userData[status]' WHERE  _id = $id";    
                }// $sql = "insert into users_table (firstname, lastname, email, dob, password, status, profile) values ('$userData[firstName]', '$lastName', '$email', '$dob', '$password', '$status', '$profile')";
                echo "$id";
                if($conn->query($sql)) {
                    $tittle = 'Edited';
                    $text = 'User '.$userData["firstName"].' '.$userData["lastName"].' Edited Successfully';
                    $_SESSION['Alert'] = alertBox('', $text, 'success');
                    
                }
                else {
                    $_SESSION['Alert'] = false;
                }
        }
                header('Location: ' . $_SERVER['PHP_SELF']);
                resetUserData($userData);
    }
        
        if(isset($_GET['action'])) {
            $getData = explode("-", $_GET['action']);
            $action = $getData[0];
            $id = $getData[1];
            if($action == "add") {
                $_SESSION['activateModal'] = true;
                $_SESSION['actionType'] = "ADD";
                resetUserData($userData);
            }
            else if($action == "delete") {
                $sql = "select * from users_table where _id = $id";
                if($result = mysqli_fetch_array($conn->query($sql))) {

                    $sql = "delete from users_table where _id = $id";
                    if($conn->query($sql)) {
                        $tittle = 'Deleted';
                        $text = 'User '.$result["firstname"].' '.$result["lastname"].' Deleted Successfully';
                        $_SESSION['Alert'] = alertBox('', $text, 'success');
                        header('Location: ' . $_SERVER['PHP_SELF']);
                    }
                    else {
                        $_SESSION['Alert'] = false;
                        header('Location: ' . $_SERVER['PHP_SELF']);
                    }
                }
                else {
                        $_SESSION['Alert'] = false;
                        header('Location: ' . $_SERVER['PHP_SELF']);
                }
            }
            else if($action == "edit") {
                $sql = "select * from users_table where _id = $id";
                if($result = mysqli_fetch_array($conn->query($sql))) {
                    $_SESSION['actionType'] = "EDIT-$id";
                    $_SESSION['activateModal'] = true;

                    $i = 1;
                    foreach($userData as $key => $value) {
                        $userData[$key] = $result[$i];
                        $i = $i + 1;
                    }
                }
                else {
                        $_SESSION['Alert'] = false;
                        header('Location: ' . $_SERVER['PHP_SELF']);
                }
            }
            else {
                $_SESSION['Alert'] = false;
                header('Location: ' . $_SERVER['PHP_SELF']);
            }
        }
?>
    <div class="wrapper">
        <!-- sidebar navigation component -->
        <!-- <nav id="sidebar" class="active">
            <div class="sidebar-header">
                <img src="assets/img/bootstraper-logo.png" alt="bootraper logo" class="app-logo">
            </div>
            <ul class="list-unstyled components text-secondary">
                <li>
                    <a href="dashboard.html"><i class="fas fa-home"></i>Dashboard</a>
                </li>
                <li>
                    <a href="forms.html"><i class="fas fa-file-alt"></i>Forms</a>
                </li>
                <li>
                    <a href="tables.html"><i class="fas fa-table"></i>Tables</a>
                </li>
                <li>
                    <a href="charts.html"><i class="fas fa-chart-bar"></i>Charts</a>
                </li>
                <li>
                    <a href="icons.html"><i class="fas fa-icons"></i>Icons</a>
                </li>
                <li>
                    <a href="#uielementsmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-layer-group"></i>UI Elements</a>
                    <ul class="collapse list-unstyled" id="uielementsmenu">
                        <li>
                            <a href="ui-buttons.html"><i class="fas fa-angle-right"></i>Buttons</a>
                        </li>
                        <li>
                            <a href="ui-badges.html"><i class="fas fa-angle-right"></i>Badges</a>
                        </li>
                        <li>
                            <a href="ui-cards.html"><i class="fas fa-angle-right"></i>Cards</a>
                        </li>
                        <li>
                            <a href="ui-alerts.html"><i class="fas fa-angle-right"></i>Alerts</a>
                        </li>
                        <li>
                            <a href="ui-tabs.html"><i class="fas fa-angle-right"></i>Tabs</a>
                        </li>
                        <li>
                            <a href="ui-date-time-picker.html"><i class="fas fa-angle-right"></i>Date & Time Picker</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#authmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-user-shield"></i>Authentication</a>
                    <ul class="collapse list-unstyled" id="authmenu">
                        <li>
                            <a href="login.html"><i class="fas fa-lock"></i>Login</a>
                        </li>
                        <li>
                            <a href="signup.html"><i class="fas fa-user-plus"></i>Signup</a>
                        </li>
                        <li>
                            <a href="forgot-password.html"><i class="fas fa-user-lock"></i>Forgot password</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#pagesmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-copy"></i>Pages</a>
                    <ul class="collapse list-unstyled" id="pagesmenu">
                        <li>
                            <a href="blank.html"><i class="fas fa-file"></i>Blank page</a>
                        </li>
                        <li>
                            <a href="404.html"><i class="fas fa-info-circle"></i>404 Error page</a>
                        </li>
                        <li>
                            <a href="500.html"><i class="fas fa-info-circle"></i>500 Error page</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="users.html"><i class="fas fa-user-friends"></i>Users</a>
                </li>
                <li>
                    <a href="settings.html"><i class="fas fa-cog"></i>Settings</a>
                </li>
            </ul>
        </nav> -->
        <!-- end of sidebar component -->
        <div id="body" class="active">
            <!-- navbar navigation component -->
            <!-- <nav class="navbar navbar-expand-lg navbar-white bg-white">
                <button type="button" id="sidebarCollapse" class="btn btn-light">
                    <i class="fas fa-bars"></i><span></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <div class="nav-dropdown">
                                <a href="#" id="nav1" class="nav-item nav-link dropdown-toggle text-secondary" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-link"></i> <span>Quick Links</span> <i style="font-size: .8em;" class="fas fa-caret-down"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end nav-link-menu" aria-labelledby="nav1">
                                    <ul class="nav-list">
                                        <li><a href="" class="dropdown-item"><i class="fas fa-list"></i> Access Logs</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-database"></i> Back ups</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-cloud-download-alt"></i> Updates</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-user-shield"></i> Roles</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <div class="nav-dropdown">
                                <a href="#" id="nav2" class="nav-item nav-link dropdown-toggle text-secondary" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user"></i> <span>John Doe</span> <i style="font-size: .8em;" class="fas fa-caret-down"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end nav-link-menu">
                                    <ul class="nav-list">
                                        <li><a href="" class="dropdown-item"><i class="fas fa-address-card"></i> Profile</a></li>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-envelope"></i> Messages</a></li>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-cog"></i> Settings</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav> -->
            <!-- end of navbar navigation -->
            <div class="content">
                <div class="container">
                    <div class="page-title">
                        <h3>Users
                        <a href="index.php?action=add" class="btn btn-sm btn-outline-primary float-end" ><i class="fas fa-plus-circle"></i> Add</a>
                        </h3>

                                    <div class="modal fade" id="exampleModal" role="dialog" tabindex="-1">
                                      <div class="modal-dialog">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <h5 class="modal-title" id="formTittle"><?php if(isset($_SESSION['actionType'])) { echo explode("-",$_SESSION['actionType'])[0].' User';  }?></h5>
                                            <a href="index.php" id="btn-close-form"><i class="fas fa-close"></i></a>
                                          </div>
                                          <div class="modal-body text-start">
                                            <form accept-charset="utf-8" style="font-size: medium !important;" action="" method="POST" enctype="multipart/form-data">
                                                <div class="mb-3">
                                                    <label for="firstName" class="form-label">First Name</label>
                                                    <input type="text" name="firstName" value="<?php echo $userData['firstName']?>" required placeholder="First Name" class="form-control">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="lastName" class="form-label">Last Name</label>
                                                    <input type="text" name="lastName" value="<?php echo $userData['lastName']?>" required placeholder="Last Name" class="form-control">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="dob" class="form-label">DOB</label>
                                                    <input type="date" name="dob" value="<?php echo $userData['dob']?>" required placeholder="DOB" class="form-control">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="email" class="form-label">Email</label>
                                                    <input type="email" name="email" value="<?php echo $userData['email']?>" required placeholder="Email Address" class="form-control">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="password" class="form-label">Password</label>
                                                    <input type="password" name="password" value="<?php echo $userData['password']?>"  required placeholder="Password" class="form-control">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="profile" class="form-label">Profile Photo</label>
                                                    <input type="file" name="profile" id="profile" onchange="imgFileHandle(event)"  <?php $temp_Data = ($userData['profile'] != "") > 0  ? '' : 'required' ; echo $temp_Data; ?> placeholder="Profile" class="form-control">
                                                </div>
                                                <?php 
                                                    if(explode("-", $_SESSION['actionType'])[0] == "EDIT") {
                                                        echo "<div class='d-flex justify-content-center'><img id='profileImg' src='./uploads/$userData[profile]' class='' height='150' /></div>";
                                                    }
                                                    else {
                                                        echo "<div class='d-flex justify-content-center'><img id='profileImg' src='' class='' style='max-height: 150px; min-height: 0px;' /></div>";
                                                    }
                                                ?>
                                                <div class="mb-3">
                                                    <label for="status" class="form-label">Status</label>
                                                    <select name="status" value="<?php echo $userData["status"];?>" class="form-control" id="">
                                                      <option value="Active">Active</option>
                                                      <option value="Inactive">Inactive</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                  </div>
                                                  <div class="modal-footer">
                                                    <a href="index.php" >Close</a>
                                                    <input type="submit" class="btn btn-primary"value="<?php $temp_Data = $_SESSION['actionType'] == "ADD" ? "ADD" : "SAVE"; echo $temp_Data;?>" />
                                                </div>
                                            </form>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                        </div>
                    </div>
                    
                    <div class="box box-primary">
                        <div class="box-body">
                            <table width="100%" class="table table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>s.no.</th>
                                        <th>Full Name</th>
                                        <th>Email</th>
                                        <th>DOB</th>
                                        <th>Password</th>
                                        <th>Status</th>
                                        <th>Photo</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 

                                    $sql = "select * from users_table";
                                    if($userData = $conn->query($sql)) {    
                                        while($row = mysqli_fetch_array($userData))

                                        echo '
                                        <tr>
                                        <td>'.$row["_id"].'</td>
                                        <td>'.ucfirst($row["firstname"]).' '.ucfirst($row["lastname"]).'</td>
                                        <td>'.$row["email"].'</td>
                                        <td>'.$row["dob"].'</td>
                                        <td>'.$row["password"].'</td>
                                        <td>'.$row["status"].'</td>
                                        <td><img src="./uploads/'.$row["profile"].'" width="100px" /></td>
                                        <td class="text-end">
                                        <a class="btn btn-outline-info btn-rounded" href="index.php?action=edit-'.$row["_id"].'"><i class="fas fa-pen"></i></a>
                                        <a class="btn btn-outline-danger btn-rounded" href="index.php?action=delete-'.$row["_id"].'"><i class="fas fa-trash"></i></a>
                                        </td>
                                        </tr>
                                        ';
                                    }
                                    else {
                                        echo "failed";
                                    }
                                    ?>
                                        
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/datatables/datatables.min.js"></script>
    <script src="assets/js/initiate-datatables.js"></script>
    <script src="assets/js/script.js"></script>
</body>
<script>
    function imgFileHandle(event) {
        var fr = new FileReader();
        fr.onload = function () {
            document.getElementById("profileImg").src = fr.result;
        }
        fr.readAsDataURL(event.target.files[0]);
    }
<?php 
if(isset($_SESSION['activateModal'])) {
    echo '
    var myModal = new bootstrap.Modal(document.getElementById("exampleModal"), { keyboard: false }); myModal.show();'; 
    unset($_SESSION['activateModal']);
}
?>
</script>
</html>